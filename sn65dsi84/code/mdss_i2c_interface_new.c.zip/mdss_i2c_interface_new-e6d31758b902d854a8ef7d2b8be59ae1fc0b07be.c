/*
*author :shaomingliang (Eliot shao)
*version:1.0
*data:2016.9.9
*function description : an i2c interface for mipi bridge or others i2c slave
*/
#include <linux/module.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/irq.h>
#include <linux/workqueue.h>
#include <linux/errno.h>
#include <linux/pm.h>
#include <linux/platform_device.h>
#include <linux/input.h>
#include <linux/i2c.h>
#include <linux/gpio.h>
#include <linux/slab.h>
#include <linux/wait.h>
#include <linux/time.h>
#include <linux/delay.h>
#include <linux/of_gpio.h>
#include <linux/pinctrl/consumer.h>

#include <linux/regulator/consumer.h>
#include <linux/notifier.h>
#include <linux/fb.h>

#include "mdss_i2c_interface.h"
#include "mdss_dsi.h"

struct mdss_i2c_interface {
	unsigned short flags;
	struct i2c_client *mdss_mipi_i2c_client;
	unsigned int slave_addr ;
	struct mutex lock;
	struct mutex i2c_lock;
	int gpio_rstn ;//sn65dsi84 复位脚
	int gpio_sn_vcc1_8v_en ;//sn65dsi84 电源使能脚
	int gpio_bkl_en ;//背光使能脚
	int gpio_lcd_5v_en ;//lcd 电源使能脚
	struct pinctrl		*pinctrl;
	struct pinctrl_state	*pin_default;
	struct pinctrl_state	*pin_sleep;
	struct regulator *vdd;
	
	struct notifier_block fb_notif;
};
#define I2C_VTG_MIN_UV__	1800000
#define I2C_VTG_MAX_UV__	1800000
static struct mdss_i2c_interface *my_mipi_i2c ;

int mdss_mipi_i2c_init_ok(void);
/*if I2C_TEST_OK == 1 stand for lt8912's i2c no ack , and the 
resource of my_mipi_i2c has been remove .must be stop here !
or will happen null pointer error !
*/

//static int I2C_TEST_OK  = 0 ; //default
	
int HDMI_WriteI2C_Byte(int reg, int val)
{
	int rc = 0;
	rc = i2c_smbus_write_byte_data(my_mipi_i2c->mdss_mipi_i2c_client,reg,val);
	if (rc < 0) {
		printk("eliot :HDMI_WriteI2C_Byte fail \n");
        return rc;
		}
	return rc ;
}
int HDMI_ReadI2C_Byte(int reg)
{
	int val = 0;
	val = i2c_smbus_read_byte_data(my_mipi_i2c->mdss_mipi_i2c_client, reg);
    if (val < 0) {
        dev_err(&my_mipi_i2c->mdss_mipi_i2c_client->dev, "i2c read fail: can't read from %02x: %d\n", 0, val);
        return val;
    } 
	return val ;
}

int Reset_chip(void)
{
	// 拉低LT8912 的reset pin，delay 150 ms左右，再拉高
	//gpio_direction_output(my_mipi_i2c->gpio_rstn, 0);
	//mdelay(10);
	gpio_direction_output(my_mipi_i2c->gpio_rstn, 1);
	mdelay(10);
	return 0;
}
int test_read(void)
{
	int val1=0,val2=0,val3=0;
	printk("eliot :test_read start \n");
	mutex_lock(&my_mipi_i2c->i2c_lock);
	my_mipi_i2c->mdss_mipi_i2c_client->addr = 0x2C;

	val1 = i2c_smbus_read_byte_data(my_mipi_i2c->mdss_mipi_i2c_client, 0x10);
	
	val2 = i2c_smbus_read_byte_data(my_mipi_i2c->mdss_mipi_i2c_client, 0x11);
	
	val3 = i2c_smbus_read_byte_data(my_mipi_i2c->mdss_mipi_i2c_client, 0x12);

	mutex_unlock(&my_mipi_i2c->i2c_lock);
	printk("eliot :test_read reg0x00:%d,reg0x01:%d,reg0x31:%d\n",val1,val2,val3);
	return 0 ;
	
}

int mdss_mipi_i2c_init(struct mdss_dsi_ctrl_pdata *ctrl, int from_mdp)
{
	mdss_mipi_i2c_init_ok();
	return 0;

}
/*This function para Get from FAE*/
int mdss_mipi_i2c_init_ok(void)
{
	printk("eliot :mdss_mipi_i2c_init_ok start \n");
	//******************************************//
		mutex_lock(&my_mipi_i2c->i2c_lock);
		my_mipi_i2c->mdss_mipi_i2c_client->addr = 0x2C; // IIC address
		/* test mode*/
		/*
		HDMI_WriteI2C_Byte(0x09,0x00);
		HDMI_WriteI2C_Byte(0x0A,0x05);
		HDMI_WriteI2C_Byte(0x0B,0x20);
		HDMI_WriteI2C_Byte(0x0D,0x00);
		HDMI_WriteI2C_Byte(0x10,0x26);
		HDMI_WriteI2C_Byte(0x11,0x00);
		HDMI_WriteI2C_Byte(0x12,0x51);
		HDMI_WriteI2C_Byte(0x13,0x00);
		HDMI_WriteI2C_Byte(0x18,0x6f);
		HDMI_WriteI2C_Byte(0x19,0x00);
		HDMI_WriteI2C_Byte(0x1A,0x03);
		HDMI_WriteI2C_Byte(0x1B,0x00);
		HDMI_WriteI2C_Byte(0x20,0xc0);
		HDMI_WriteI2C_Byte(0x21,0x03);
		HDMI_WriteI2C_Byte(0x22,0x00);
		HDMI_WriteI2C_Byte(0x23,0x00);
		HDMI_WriteI2C_Byte(0x24,0x38);
		HDMI_WriteI2C_Byte(0x25,0x04);
		HDMI_WriteI2C_Byte(0x26,0x00);
		HDMI_WriteI2C_Byte(0x27,0x00);
		HDMI_WriteI2C_Byte(0x28,0xc1);
		HDMI_WriteI2C_Byte(0x29,0x00);
		HDMI_WriteI2C_Byte(0x2A,0x00);
		HDMI_WriteI2C_Byte(0x2B,0x00);
		HDMI_WriteI2C_Byte(0x2C,0x20);
		HDMI_WriteI2C_Byte(0x2D,0x00);
		HDMI_WriteI2C_Byte(0x2E,0x00);
		HDMI_WriteI2C_Byte(0x2F,0x00);
		HDMI_WriteI2C_Byte(0x30,0x04);
		HDMI_WriteI2C_Byte(0x31,0x00);
		HDMI_WriteI2C_Byte(0x32,0x00);
		HDMI_WriteI2C_Byte(0x33,0x00);
		HDMI_WriteI2C_Byte(0x34,0x30);
		HDMI_WriteI2C_Byte(0x35,0x00);
		HDMI_WriteI2C_Byte(0x36,0x08);
		HDMI_WriteI2C_Byte(0x37,0x00);
		HDMI_WriteI2C_Byte(0x38,0x30);
		HDMI_WriteI2C_Byte(0x39,0x00);
		HDMI_WriteI2C_Byte(0x3A,0x08);
		HDMI_WriteI2C_Byte(0x3B,0x00);
		HDMI_WriteI2C_Byte(0x3C,0x10);
		HDMI_WriteI2C_Byte(0x3D,0x00);
		HDMI_WriteI2C_Byte(0x3E,0x00);		
*/
		/* work mode*/
		HDMI_WriteI2C_Byte(0x09,0x00);
		HDMI_WriteI2C_Byte(0x0A,0x05);
		HDMI_WriteI2C_Byte(0x0B,0x20);
		HDMI_WriteI2C_Byte(0x0D,0x00);
		HDMI_WriteI2C_Byte(0x10,0x26);
		HDMI_WriteI2C_Byte(0x11,0x00);
		HDMI_WriteI2C_Byte(0x12,0x51);
		HDMI_WriteI2C_Byte(0x13,0x00);
		HDMI_WriteI2C_Byte(0x18,0x6C);//HDMI_WriteI2C_Byte(0x18,0x6f);
		HDMI_WriteI2C_Byte(0x19,0x00);
		HDMI_WriteI2C_Byte(0x1A,0x03);
		HDMI_WriteI2C_Byte(0x1B,0x00);
		HDMI_WriteI2C_Byte(0x20,0x80);
		HDMI_WriteI2C_Byte(0x21,0x07);
		HDMI_WriteI2C_Byte(0x22,0x00);
		HDMI_WriteI2C_Byte(0x23,0x00);
		HDMI_WriteI2C_Byte(0x24,0x00);
		HDMI_WriteI2C_Byte(0x25,0x00);
		HDMI_WriteI2C_Byte(0x26,0x00);
		HDMI_WriteI2C_Byte(0x27,0x00);
		HDMI_WriteI2C_Byte(0x28,0xc1);
		HDMI_WriteI2C_Byte(0x29,0x00);
		HDMI_WriteI2C_Byte(0x2A,0x00);
		HDMI_WriteI2C_Byte(0x2B,0x00);
		HDMI_WriteI2C_Byte(0x2C,0x20);
		HDMI_WriteI2C_Byte(0x2D,0x00);
		HDMI_WriteI2C_Byte(0x2E,0x00);
		HDMI_WriteI2C_Byte(0x2F,0x00);
		HDMI_WriteI2C_Byte(0x30,0x04);
		HDMI_WriteI2C_Byte(0x31,0x00);
		HDMI_WriteI2C_Byte(0x32,0x00);
		HDMI_WriteI2C_Byte(0x33,0x00);
		HDMI_WriteI2C_Byte(0x34,0x30);
		HDMI_WriteI2C_Byte(0x35,0x00);
		HDMI_WriteI2C_Byte(0x36,0x00);
		HDMI_WriteI2C_Byte(0x37,0x00);
		HDMI_WriteI2C_Byte(0x38,0x00);
		HDMI_WriteI2C_Byte(0x39,0x00);
		HDMI_WriteI2C_Byte(0x3A,0x00);
		HDMI_WriteI2C_Byte(0x3B,0x00);
		HDMI_WriteI2C_Byte(0x3C,0x00);
		HDMI_WriteI2C_Byte(0x3D,0x00);
		HDMI_WriteI2C_Byte(0x3E,0x00);	
		
		HDMI_WriteI2C_Byte(0x0d,0x01);
		mdelay(5);
		HDMI_WriteI2C_Byte(0x09,0x01);
		mdelay(5);
	mutex_unlock(&my_mipi_i2c->i2c_lock);

	//printk("eliot :mdss_mipi_i2c_init end \n");
	return 0 ;
	
}

EXPORT_SYMBOL_GPL(mdss_mipi_i2c_init);
#if 0
static int lt_pinctrl_init(struct mdss_i2c_interface *lt)
{
	struct i2c_client *client = lt->mdss_mipi_i2c_client;

	lt->pinctrl = devm_pinctrl_get(&client->dev);
	if (IS_ERR_OR_NULL(lt->pinctrl)) {
		dev_err(&client->dev, "Failed to get pinctrl\n");
		return PTR_ERR(lt->pinctrl);
	}

	lt->pin_default = pinctrl_lookup_state(lt->pinctrl, "default");
	if (IS_ERR_OR_NULL(lt->pin_default)) {
		dev_err(&client->dev, "Failed to look up default state\n");
		return PTR_ERR(lt->pin_default);
	}

	lt->pin_sleep = pinctrl_lookup_state(lt->pinctrl, "sleep");
	if (IS_ERR_OR_NULL(lt->pin_sleep)) {
		dev_err(&client->dev, "Failed to look up sleep state\n");
		return PTR_ERR(lt->pin_sleep);
	}

	return 0;
}
#endif 
static int mipi_i2c_resume(struct device *tdev) {
	int err;
	printk(KERN_ERR "eliot :mipi_i2c_resume  \n");
	regulator_set_voltage(my_mipi_i2c->vdd, I2C_VTG_MIN_UV__,
					   I2C_VTG_MAX_UV__);
		err = regulator_enable(my_mipi_i2c->vdd);
		if(err <0){
			printk(KERN_ERR "eliot:vdd enable erro err = %d\n",err);
			//goto exit2;
		}
		gpio_direction_output(my_mipi_i2c->gpio_bkl_en, 1);
		gpio_direction_output(my_mipi_i2c->gpio_lcd_5v_en, 1);
		gpio_direction_output(my_mipi_i2c->gpio_sn_vcc1_8v_en, 1);
		Reset_chip();
		
		//mdss_mipi_i2c_init_ok();
		
    return 0;
}

static int mipi_i2c_suspend(struct device *tdev) {
	printk(KERN_ERR "eliot :mipi_i2c_suspend  \n");
	regulator_disable(my_mipi_i2c->vdd);
		HDMI_WriteI2C_Byte(0x0d,0x0);
		gpio_direction_output(my_mipi_i2c->gpio_rstn, 0);
		gpio_direction_output(my_mipi_i2c->gpio_bkl_en, 0);
		gpio_direction_output(my_mipi_i2c->gpio_lcd_5v_en, 0);
		gpio_direction_output(my_mipi_i2c->gpio_sn_vcc1_8v_en, 0);
    return 0;
}
#if defined(CONFIG_FB)
static int fb_notifier_callback(struct notifier_block *self,
				 unsigned long event, void *data)
{
	struct fb_event *evdata = data;
	int *blank;
	//struct my_mipi_i2c *cxn =
	//	container_of(self, struct my_mipi_i2c, fb_notif);
	printk(KERN_ERR "eliot :fb_notifier_callback  \n");

	if (evdata && evdata->data && event == FB_EVENT_BLANK &&
			my_mipi_i2c && my_mipi_i2c->mdss_mipi_i2c_client) {
		blank = evdata->data;
		if (*blank == FB_BLANK_UNBLANK){
			printk(KERN_ERR "eliot :fb_notifier_callback 1 \n");
			//mipi_i2c_resume(&my_mipi_i2c->mdss_mipi_i2c_client->dev);
			}
		else if (*blank == FB_BLANK_POWERDOWN){
			printk(KERN_ERR "eliot :fb_notifier_callback 2  \n");
			//mipi_i2c_suspend(&my_mipi_i2c->mdss_mipi_i2c_client->dev);
			}
	}

	return 0;
}
#endif
/*
	1.get reset pin and request gpio ;
	2.get i2c client ,check i2c function and test read i2c slave ;
	3.send lt8912 i2c configuration table
*/
static int mipi_i2c_probe(struct i2c_client *client,
        const struct i2c_device_id *id) 
{
    int err;
	//struct mdss_dsi_ctrl_pdata *ctrl=NULL;
	//int from_mdp=0 ;

	printk("eliot :mipi_i2c_probe start.....");
	
	if (!i2c_check_functionality(client->adapter, I2C_FUNC_I2C)) {
		dev_err(&client->dev,
				"%s: check_functionality failed.", __func__);
		err = -ENODEV;
		goto exit0;
	}

	/* Allocate memory for driver data */
	my_mipi_i2c = kzalloc(sizeof(struct mdss_i2c_interface), GFP_KERNEL);
	if (!my_mipi_i2c) {
		dev_err(&client->dev,
				"%s: memory allocation failed.", __func__);
		err = -ENOMEM;
		goto exit1;
	}
	
	mutex_init(&my_mipi_i2c->lock);
	mutex_init(&my_mipi_i2c->i2c_lock);


	if (client->dev.of_node) {
	my_mipi_i2c->gpio_rstn = of_get_named_gpio_flags(client->dev.of_node,
			"ti,gpio_rstn", 0, NULL);
		printk("eliot:my_mipi_i2c->gpio_rstn=%d\n",my_mipi_i2c->gpio_rstn);
	my_mipi_i2c->gpio_bkl_en = of_get_named_gpio_flags(client->dev.of_node,
			"bkl,en", 0, NULL);
		printk("eliot:my_mipi_i2c->gpio_bkl_en=%d\n",my_mipi_i2c->gpio_bkl_en);
	my_mipi_i2c->gpio_lcd_5v_en = of_get_named_gpio_flags(client->dev.of_node,
			"lcd,vcc5v_en", 0, NULL);
		printk("eliot:my_mipi_i2c->gpio_lcd_5v_en=%d\n",my_mipi_i2c->gpio_lcd_5v_en);
	my_mipi_i2c->gpio_sn_vcc1_8v_en = of_get_named_gpio_flags(client->dev.of_node,
			"ti,vcc1_8v_en", 0, NULL);
		printk("eliot:my_mipi_i2c->gpio_sn_vcc1_8v_en=%d\n",my_mipi_i2c->gpio_sn_vcc1_8v_en);
	}
	else
	{
		printk("eliot:client->dev.of_node not exit!\n");
	}

	/***** I2C initialization *****/
	my_mipi_i2c->mdss_mipi_i2c_client = client;
	
	/* set client data */
	i2c_set_clientdata(client, my_mipi_i2c);
#if 0
	/* initialize pinctrl */
	if (!lt_pinctrl_init(my_mipi_i2c)) {
		err = pinctrl_select_state(my_mipi_i2c->pinctrl, my_mipi_i2c->pin_default);
		if (err) {
			dev_err(&client->dev, "Can't select pinctrl state\n");
			goto exit1;
		}
	}
#endif
	my_mipi_i2c->vdd = regulator_get(&client->dev, "vdd");
	
	if (IS_ERR(my_mipi_i2c->vdd)) {
		err = PTR_ERR(my_mipi_i2c->vdd);
		printk(KERN_ERR "eliot:vdd get erro err = %d\n",err);
		goto exit2;
	}else
	{
		regulator_set_voltage(my_mipi_i2c->vdd, I2C_VTG_MIN_UV__,
					   I2C_VTG_MAX_UV__);
		err = regulator_enable(my_mipi_i2c->vdd);
		if(err <0){
			printk(KERN_ERR "eliot:vdd enable erro err = %d\n",err);
			goto exit2;
			}
	}
	
	mutex_lock(&my_mipi_i2c->lock);

	if (gpio_request(my_mipi_i2c->gpio_bkl_en, "gpio_bkl_en") < 0) {
		mutex_unlock(&my_mipi_i2c->lock);
		printk("Failed to request GPIO:%d, ERRNO:%d",
			  my_mipi_i2c->gpio_bkl_en, err);
		err = -ENODEV;
		goto exit2;
	}else{
		gpio_direction_output(my_mipi_i2c->gpio_bkl_en, 1);
	}
	if (gpio_request(my_mipi_i2c->gpio_lcd_5v_en, "gpio_lcd_5v_en") < 0) {
		mutex_unlock(&my_mipi_i2c->lock);
		printk("Failed to request GPIO:%d, ERRNO:%d",
			  my_mipi_i2c->gpio_lcd_5v_en, err);
		err = -ENODEV;
		goto exit2;
	}else{
		gpio_direction_output(my_mipi_i2c->gpio_lcd_5v_en, 1);
	}
	if (gpio_request(my_mipi_i2c->gpio_sn_vcc1_8v_en, "gpio_sn_vcc1_8v_en") < 0) {
		mutex_unlock(&my_mipi_i2c->lock);
		printk("Failed to request GPIO:%d, ERRNO:%d",
			  my_mipi_i2c->gpio_sn_vcc1_8v_en, err);
		err = -ENODEV;
		goto exit2;
	}else{
		gpio_direction_output(my_mipi_i2c->gpio_sn_vcc1_8v_en, 1);
	}
	/* Pull up the reset pin */
	/* request  GPIO  */
	err = gpio_request(my_mipi_i2c->gpio_rstn, "sn,gpio_rstn");
	if (err < 0) {
		mutex_unlock(&my_mipi_i2c->lock);
		printk("Failed to request GPIO:%d, ERRNO:%d",
			  my_mipi_i2c->gpio_rstn, err);
		err = -ENODEV;
		goto exit2;
	}else{
		//gpio_direction_output(my_mipi_i2c->gpio_rstn, 0);
		//mdelay(10);
		gpio_direction_output(my_mipi_i2c->gpio_rstn, 1);
		mdelay(10);
	}
	//my_mipi_i2c->mdss_mipi_i2c_client->addr = 0x2C;
    err = i2c_smbus_read_byte_data(client, 0x0a);
    if (err < 0) {
    	printk("eliot i2c test Failed ret = %d\n",err);
		//I2C_TEST_OK = 1 ;
		mutex_unlock(&my_mipi_i2c->lock);
		gpio_direction_output(my_mipi_i2c->gpio_rstn, 0);
		gpio_direction_output(my_mipi_i2c->gpio_bkl_en, 0);
		gpio_direction_output(my_mipi_i2c->gpio_lcd_5v_en, 0);
		gpio_direction_output(my_mipi_i2c->gpio_sn_vcc1_8v_en, 0);
		gpio_free(my_mipi_i2c->gpio_rstn);
		gpio_free(my_mipi_i2c->gpio_bkl_en);
		gpio_free(my_mipi_i2c->gpio_lcd_5v_en);
		gpio_free(my_mipi_i2c->gpio_sn_vcc1_8v_en);
		dev_err(&client->dev, "i2c read fail: can't read from %02x: %d\n", 0, err);
        goto exit2;
    } 
    printk("eliot sn65dsi84 i2c test ok .id = %d\n",err);
   	#if defined(CONFIG_FB)
		my_mipi_i2c->fb_notif.notifier_call = fb_notifier_callback;
		err = fb_register_client(&my_mipi_i2c->fb_notif);
		if (err)
			printk(KERN_ERR "eliot :fb_notifier_callback err.....");
	#endif
	//mdss_mipi_i2c_init_ok();
	//test_read();
	mutex_unlock(&my_mipi_i2c->lock);
	printk("eliot :mipi_i2c_probe end ....\n");
	return 0;

exit2:
	regulator_put(my_mipi_i2c->vdd);
exit1:
	kfree(my_mipi_i2c);
exit0:
	return err;

}

static const struct of_device_id mipi_i2c_of_match[] = {
    { .compatible = "qcom,sn65dsi84",},
    {},
};

static const struct i2c_device_id mipi_i2c_id[] = {
    {"qcom,sn65dsi84", 0},
    {},
};


static int mipi_i2c_remove(struct i2c_client *client) {
	
    return 0;
}

static const struct dev_pm_ops mipi_i2c_pm_ops =
{ 
    .suspend = mipi_i2c_suspend,
    .resume = mipi_i2c_resume, 
};


static struct i2c_driver mipi_i2c_driver = {
    .driver = {
        .name = "qcom,sn65dsi84",
        .owner    = THIS_MODULE,
        .of_match_table = mipi_i2c_of_match,
        //.pm = &mipi_i2c_pm_ops,
    },
    .probe    = mipi_i2c_probe,
    .remove   = mipi_i2c_remove,
    .id_table = mipi_i2c_id,
};

module_i2c_driver(mipi_i2c_driver);

MODULE_LICENSE("GPL");

