/*
eliot shao 2017/2/6
for icn6211 mipi to rgb bridge
*/

#include <i2c_qup.h>
#include <blsp_qup.h>

#include <debug.h>
#include <err.h>
#include <mipi_dsi.h>
#include <boot_stats.h>
#include <platform/gpio.h>
#include <msm_panel.h>
#include <mipi_dsi.h>
#include <board.h>
//#include <mdp5.h>
#include <scm.h>
#include <platform/iomap.h>

#include <gpio_i2c.h>

#include "include/display_resource.h"


#define  Slave_addr   0x2c

unsigned char data = 0 ;
//unsigned char buf[10]={0};
int sn65dsi84_Init(void)
{

	dprintf(CRITICAL, "eliot:sn65dsi84_Init");
	gpio_tlmm_config(94, 0, 1, 0, 3, 1);//backlight 
	gpio_tlmm_config(126, 0, 1, 0, 3, 1);//1.8v
	gpio_tlmm_config(129, 0, 1, 0, 3, 1);//5v
	gpio_tlmm_config(130, 0, 1, 0, 3, 1);//reset
	
	gpio_set_dir(94, 2);
	gpio_set_dir(126, 2);
	gpio_set_dir(129, 2);
	mdelay(10);
	gpio_set_dir(130, 2);
  	mdelay(50);

	data = i2c_read_one(Slave_addr,0x0a);
	if(data != 0x0a){
		dprintf(CRITICAL, "eliot:sn65dsi84_Init i2c init erro !!!! err.. = 0x%x\n",data);
		return 0;
	}
	i2c_write_one(0x09,0x00);
	i2c_write_one(0x0A,0x05);
	i2c_write_one(0x0B,0x20);
	i2c_write_one(0x0D,0x00);
	i2c_write_one(0x10,0x26);
	i2c_write_one(0x11,0x00);
	i2c_write_one(0x12,0x51);
	i2c_write_one(0x13,0x00);
	i2c_write_one(0x18,0x6C);
	i2c_write_one(0x19,0x00);
	i2c_write_one(0x1A,0x03);
	i2c_write_one(0x1B,0x00);
	i2c_write_one(0x20,0x80);
	i2c_write_one(0x21,0x07);
	i2c_write_one(0x22,0x00);
	i2c_write_one(0x23,0x00);
	i2c_write_one(0x24,0x00);
	i2c_write_one(0x25,0x00);
	i2c_write_one(0x26,0x00);
	i2c_write_one(0x27,0x00);
	i2c_write_one(0x28,0xc1);
	i2c_write_one(0x29,0x00);
	i2c_write_one(0x2A,0x00);
	i2c_write_one(0x2B,0x00);
	i2c_write_one(0x2C,0x20);
	i2c_write_one(0x2D,0x00);
	i2c_write_one(0x2E,0x00);
	i2c_write_one(0x2F,0x00);
	i2c_write_one(0x30,0x04);
	i2c_write_one(0x31,0x00);
	i2c_write_one(0x32,0x00);
	i2c_write_one(0x33,0x00);
	i2c_write_one(0x34,0x30);
	i2c_write_one(0x35,0x00);
	i2c_write_one(0x36,0x00);
	i2c_write_one(0x37,0x00);
	i2c_write_one(0x38,0x00);
	i2c_write_one(0x39,0x00);
	i2c_write_one(0x3A,0x00);
	i2c_write_one(0x3B,0x00);
	i2c_write_one(0x3C,0x00);
	i2c_write_one(0x3D,0x00);
	i2c_write_one(0x3E,0x00);

	i2c_write_one(0x0d,0x01);
	mdelay(5);
	i2c_write_one(0x09,0x01);
	mdelay(5);
	//data = i2c_read_one(Slave_addr,0x18);
	//dprintf(CRITICAL, "eliot:icn6211 i2c init OK !!!! data.. = 0x%x(0x6c)\n",data);
	return 0;
	
}




